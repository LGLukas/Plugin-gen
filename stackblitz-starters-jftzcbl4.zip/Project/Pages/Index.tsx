import { useState, useRef, useEffect } from 'react';
import { ArrowRight, Download, Code, Wand2 } from 'lucide-react';
import axios from 'axios';

type GenerationState = 'idle' | 'loading' | 'success' | 'error';

export default function PluginGenerator() {
  const [input, setInput] = useState('');
  const [code, setCode] = useState('');
  const [state, setState] = useState<GenerationState>('idle');
  const [error, setError] = useState('');
  const codeRef = useRef<HTMLPreElement>(null);

  // Auto-Scroll zu neuem Code
  useEffect(() => {
    if (code && codeRef.current) {
      codeRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [code]);

  const generatePlugin = async () => {
    if (!input.trim()) {
      setError('Bitte beschreiben Sie Ihr Plugin');
      return;
    }

    setState('loading');
    setError('');

    try {
      const response = await axios.post('/api/generate', {
        prompt: input,
        existingCode: code || null
      });

      setCode(response.data.code);
      setState('success');
    } catch (err) {
      console.error('Generation error:', err);
      setError(err.response?.data?.error || 'Generierung fehlgeschlagen');
      setState('error');
    }
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/x-java-source' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MinecraftPlugin_${new Date().toISOString().slice(0,10)}.java`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-gray-100">
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <header className="mb-12 text-center">
          <h1 className="text-4xl font-bold mb-2 flex justify-center items-center gap-3">
            <Wand2 className="text-yellow-400" /> 
            Minecraft Plugin Generator
          </h1>
          <p className="text-gray-400">
            Beschreiben Sie Ihr Plugin in natürlicher Sprache
          </p>
        </header>

        <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
          <div className="flex gap-3 mb-6">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="z.B. 'Plugin mit /fly und Cooldown'"
              className="flex-1 bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:ring-2 focus:ring-yellow-500 focus:outline-none"
              disabled={state === 'loading'}
              onKeyDown={(e) => e.key === 'Enter' && generatePlugin()}
            />
            <button
              onClick={generatePlugin}
              disabled={state === 'loading'}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
                state === 'loading'
                  ? 'bg-gray-600 cursor-not-allowed'
                  : 'bg-yellow-600 hover:bg-yellow-500'
              }`}
            >
              {state === 'loading' ? (
                'Generiert...'
              ) : (
                <>
                  <ArrowRight size={18} />
                  Generieren
                </>
              )}
            </button>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-900/50 border border-red-700 rounded-lg">
              {error}
            </div>
          )}

          {code && (
            <div className="mt-8">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold flex items-center gap-2">
                  <Code className="text-yellow-400" />
                  Generierter Code
                </h2>
                <button
                  onClick={handleDownload}
                  className="flex items-center gap-2 bg-green-700 hover:bg-green-600 px-4 py-2 rounded-lg"
                >
                  <Download size={16} />
                  Download
                </button>
              </div>
              <pre
                ref={codeRef}
                className="bg-gray-900 p-4 rounded-lg overflow-x-auto text-sm border border-gray-700"
              >
                {code}
              </pre>
            </div>
          )}
        </div>

        <footer className="mt-12 text-center text-gray-500 text-sm">
          <p>Verwenden Sie generierte Plugins nur auf eigenen Servern</p>
        </footer>
      </div>
    </div>
  );
}