import { NextApiRequest, NextApiResponse } from 'next';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_KEY
});

const SYSTEM_PROMPT = `Du bist ein Minecraft-Spigot-Plugin-Experte. Generiere nur:
1. Vollständigen Java-Code
2. Mit korrekten Imports
3. Keine Erklärungen
4. Formatierung für IDE`;

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { prompt, existingCode } = req.body;

  try {
    const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      { role: 'system', content: SYSTEM_PROMPT }
    ];

    if (existingCode) {
      messages.push({
        role: 'assistant',
        content: existingCode
      });
    }

    messages.push({
      role: 'user',
      content: `Neue Anforderung: ${prompt}`
    });

    const completion = await openai.chat.completions.create({
      model: "gpt-4-turbo",
      messages,
      temperature: 0.2,
      max_tokens: 2000
    });

    const generatedCode = completion.choices[0].message.content;
    res.status(200).json({ code: generatedCode });

  } catch (error) {
    console.error('API Error:', error);
    res.status(500).json({ 
      error: 'Plugin generation failed',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
}
